// components/UserLayout.tsx
import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import axios from 'axios'
import Link from 'next/link'

export default function UserLayout({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<{ email: string } | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axios.get('/api/auth/me', { withCredentials: true })
        setUser(res.data)
      } catch {
        router.push('/login') // если не авторизован — редирект на логин
      } finally {
        setLoading(false)
      }
    }
    fetchUser()
  }, [router])

  const logout = async () => {
    await axios.post('/api/auth/logout')
    router.reload()
  }

  if (loading) return <div className="p-4">Загрузка...</div>

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <header className="flex justify-between items-center bg-white shadow p-4 mb-4 rounded">
        <div>
          👤 {user?.email}
        </div>
        <nav className="space-x-4">
          <Link href="/profile" className="text-blue-600 hover:underline">Профиль</Link>
          <Link href="/orders" className="text-blue-600 hover:underline">Мои заказы</Link>
          <button onClick={logout} className="text-red-500 hover:underline">Выйти</button>
        </nav>
      </header>

      <main>{children}</main>
    </div>
  )
}
