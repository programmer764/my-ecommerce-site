// components/SearchBar.js
import { useState } from "react";
import { useRouter } from "next/router";

const SearchBar = () => {
  const router = useRouter();
  const { search } = router.query;
  const [searchQuery, setSearchQuery] = useState(search || "");

  // Функция для применения поиска
  const handleSearch = () => {
    const query = {};
    if (searchQuery.trim()) {
      query.search = searchQuery.trim();
    }
    router.push({ pathname: "/", query });
  };

  return (
    <div className="flex items-center space-x-2">
      <input
        type="text"
        placeholder="Поиск по названию..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="border p-2 rounded w-96"
      />
      <button
        className="bg-blue-500 text-white px-4 py-2 rounded"
        onClick={handleSearch}
      >
        Искать
      </button>
    </div>
  );
};

export default SearchBar;

