import Link from 'next/link'
import Image from 'next/image'
import SearchBar from './SearchBar'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import axios from 'axios'

const DesktopHeader = () => {
  const [user, setUser] = useState(null)
  const router = useRouter()

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axios.get('/api/auth/me', { withCredentials: true })
        setUser(res.data)
      } catch {
        setUser(null)
      }
    }

    fetchUser()
    const handleRouteChange = () => fetchUser()
    router.events?.on('routeChangeComplete', handleRouteChange)

    return () => {
      router.events?.off('routeChangeComplete', handleRouteChange)
    }
  }, [router])

  const handleLogout = async () => {
    await axios.post('/api/auth/logout')
    setUser(null)
    router.push('/login')
  }

  return (
    <header className="bg-white text-black py-4 shadow-md relative z-50">
      {/* Навигационное меню */}
      <nav className="bg-gradient-to-r from-blue-200 to-gray-300 py-2 px-4 shadow-md text-sm">
        <ul className="flex justify-center items-center gap-4 whitespace-nowrap">
          <li><a href="#about" className="text-gray-800 hover:text-blue-700 transition">О компании</a></li>
          <li><a href="#payment" className="text-gray-800 hover:text-blue-700 transition">Оплата и доставка</a></li>
          <li><a href="#guarantee" className="text-gray-800 hover:text-blue-700 transition">Гарантия</a></li>
          <li><a href="#projects" className="text-gray-800 hover:text-blue-700 transition">Наши работы</a></li>
          <li><a href="#installation" className="text-gray-800 hover:text-blue-700 transition">Монтаж и согласование</a></li>
          <li><a href="#contact" className="text-gray-800 hover:text-blue-700 transition">Контакты</a></li>
        </ul>
      </nav>
      <div className="container mx-auto flex justify-between items-center px-4 flex-wrap mt-4">
        {/* Логотип */}
        <div className="flex items-center space-x-2">
          <Link href="/">
            <Image src="/icons/logo2.svg" alt="Логотип" width={150} height={150} />
          </Link>
          <span className="text-2xl font-bold text-blue-800">ClimaTrade</span>
        </div>

        {/* Поиск */}
        <div className="my-2 md:my-0">
          <SearchBar />
        </div>

        {/* Контакт и соцсети */}
        <div className="flex items-center gap-4 mt-2 md:mt-0">
          <div className="flex items-center gap-2 ml-3 mr-5">
            <Image src="/icons/c1.svg" alt="Телефон" width={32} height={32} />
            <div className="flex flex-col leading-tight">
              <span className="text-blue-800 text-lg font-semibold whitespace-nowrap">
                +7 (123) 456-78-90
              </span>
              <span className="text-sm text-gray-600">с 10:00 до 18:00</span>
            </div>
          </div>
          <Link href="/"><Image src="/icons/m1.svg" alt="m1" width={32} height={32} /></Link>
          <Link href="/"><Image src="/icons/t1.svg" alt="t1" width={32} height={32} /></Link>
          <Link href="/"><Image src="/icons/f1.svg" alt="f1" width={32} height={32} /></Link>
          <Link href="/"><Image src="/icons/tw1.svg" alt="tw1" width={32} height={32} /></Link>

          {/* Пользователь / Гость */}
          <div className="relative ml-4 group">
            {user ? (
              <div className="cursor-pointer px-3 py-2 bg-blue-100 rounded group-hover:bg-blue-200 transition">
                👤 {user.email}
                <div className="absolute right-0 mt-2 bg-white border shadow-md rounded hidden group-hover:block min-w-[200px] z-50">
                  <Link href="/profile" className="block px-4 py-2 hover:bg-gray-100">Профиль</Link>
                  <Link href="/orders" className="block px-4 py-2 hover:bg-gray-100">Мои заказы</Link>

                  {/* Если админ — показываем ссылки на админку */}
                  {user.role === 'admin' && (
                    <>
                      <div className="px-4 py-1 text-xs text-gray-500">Администрирование</div>
                      <Link href="/admin/orders" className="block px-4 py-2 hover:bg-gray-100">📦 Заказы</Link>
                      <Link href="/admin/products" className="block px-4 py-2 hover:bg-gray-100">📦 Товары</Link>
                      <Link href="/admin/users" className="block px-4 py-2 hover:bg-gray-100">👥 Пользователи</Link>
                      <Link href="/admin/excel" className="block px-4 py-2 hover:bg-gray-100">📊 Excel</Link>
                    </>
                  )}

                  <button
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 hover:bg-gray-100 text-red-600"
                  >
                    Выйти
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex gap-2">
                <Link href="/login" className="text-sm text-blue-600 hover:underline">
                  Войти
                </Link>
                <Link href="/register" className="text-sm text-blue-600 hover:underline">
                  Зарегистрироваться
                </Link>
              </div>
            )}

          </div>
        </div>
      </div>
      <nav className="bg-[#2a7bbc] p-4 mt-6">
        <div className="container mx-auto text-white">
          {/* Сетка 5 колонок и 3 строки */}
          <ul className="grid grid-cols-6 grid-rows-2 gap-x-2 gap-y-2 text-center">
            <li className="relative group">
              <Link href="/catalog/nastennye-konditsionery-split-sistemy">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l1.svg" alt="Кондиционеры" width={20} height={20} />
                  <span>Настенные кондиционеры</span>
                </span>
              </Link>
            </li>
            <li className="relative group">
              <Link href="/catalog/multi-split-sistemy">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l6.svg" alt="Мульти сплит" width={20} height={20} />
                  <span>Мульти сплит-системы</span>
                </span>
              </Link>
            </li>
            <li>
              <Link href="/catalog/kanalnye-konditsionery">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l2.svg" alt="Канальные" width={20} height={20} />
                  <span>Канальные кондиционеры</span>
                </span>
              </Link>
            </li>
            <li>
              <Link href="/catalog/kassetnye-konditsionery">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l4.svg" alt="Кассетные" width={20} height={20} />
                  <span>Кассетные кондиционеры</span>
                </span>
              </Link>
            </li>
            <li>
              <Link href="/catalog/mobilnye-konditsionery">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l5.svg" alt="Мобильные" width={20} height={20} />
                  <span>Мобильные кондиционеры</span>
                </span>
              </Link>
            </li>

            {/* Вторая строка */}
            <li>
              <Link href="/catalog/napolno-potolochnye">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l6.svg" alt="Напольно-потолочные" width={20} height={20} />
                  <span>Напольно-потолочные</span>
                </span>
              </Link>
            </li>
            <li>
              <Link href="/catalog/multizonalnye-vrf">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l7.svg" alt="VRF" width={20} height={20} />
                  <span>Мультизональные VRF</span>
                </span>
              </Link>
            </li>
            <li>
              <Link href="/catalog/fankoyly">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l1.svg" alt="Фанкойлы" width={20} height={20} />
                  <span>Фанкойлы</span>
                </span>
              </Link>
            </li>
            <li>
              <Link href="/catalog/kolonnye">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l2.svg" alt="Колонные" width={20} height={20} />
                  <span>Колонные кондиционеры</span>
                </span>
              </Link>
            </li>
            <li>
              <Link href="/catalog/teplovye-nasosy">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l3.svg" alt="Тепловые насосы" width={20} height={20} />
                  <span>Тепловые насосы</span>
                </span>
              </Link>
            </li>

            {/* Третья строка */}
            <li>
              <Link href="/catalog/okonnye-konditsionery">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l4.svg" alt="Оконные" width={20} height={20} />
                  <span>Оконные кондиционеры</span>
                </span>
              </Link>
            </li>
            <li>
              <Link href="/catalog/holodilnye-split-sistemy">
                <span className="flex flex-col items-center hover:bg-white hover:text-[#2a7bbc] px-4 py-2 rounded transition-colors">
                  <Image src="/icons/l5.svg" alt="Холодильные" width={20} height={20} />
                  <span>Холодильные системы</span>
                </span>
              </Link>
            </li>

          </ul>
        </div>
      </nav>


    </header>
  )
}

export default DesktopHeader
