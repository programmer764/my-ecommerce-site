// pages/index.js
import { useState, useEffect } from 'react'
import axios from 'axios'
import clientPromise from '@/lib/mongo'
import ProductCard   from '@/components/ProductCard'
import ProductFilter from '@/components/ProductFilter'
import Pagination    from '@/components/Pagination'
import FilterButton  from '@/components/FilterButton'


export async function getServerSideProps({ query }) {
  // 1) Получаем товары + общее число
  const { data } = await axios.get(
    `${process.env.NEXT_PUBLIC_BASE_URL}/api/products`,
    { params: query }
  )
  const { products, totalCount } = data

  // 2) Собираем бренды и страны из ВСЕХ товаров
  const client = await clientPromise
  const coll   = client.db('dbcom').collection('dbcom2')

  const docsB = await coll
    .find({ 'characteristics.name': 'Производитель' })
    .project({ characteristics: 1 })
    .toArray()
  const availableBrands = Array.from(new Set(
    docsB
      .map(d => d.characteristics.find(c => c.name === 'Производитель')?.value)
      .filter(Boolean)
  ))

  const docsC = await coll
    .find({ 'characteristics.name': 'Страна бренда' })
    .project({ characteristics: 1 })
    .toArray()
  const availableCountries = Array.from(new Set(
    docsC
      .map(d => d.characteristics.find(c => c.name === 'Страна бренда')?.value)
      .filter(Boolean)
  ))

  return {
    props: {
      products,
      totalCount,
      currentPage: parseInt(query.page || '1', 10),
      availableBrands,
      availableCountries
    }
  }
}

export default function Home({
  products,
  totalCount,
  currentPage,
  availableBrands,
  availableCountries
}) {
  const [showFilter, setShowFilter] = useState(false)
  const [isClient,   setIsClient]   = useState(false)
  useEffect(() => setIsClient(true), [])

  const totalPages = Math.ceil(totalCount / 15)

  return (
    <div className="p-4 flex flex-col lg:flex-row gap-4">
      {/* мобильная кнопка */}
      <div className="mb-2 lg:hidden">
        <FilterButton
          showFilter={showFilter}
          toggleFilter={() => setShowFilter(!showFilter)}
        />
      </div>

      {/* фильтр */}
      {isClient && (
        <aside className={`w-full lg:w-[250px] ${showFilter ? 'block' : 'hidden'} lg:block`}>
          <ProductFilter
            availableBrands={availableBrands}
            availableCountries={availableCountries}
          />
        </aside>
      )}

      {/* товары */}
      <main className="flex-1 min-w-0">
        <h1 className="text-2xl mb-6 text-center font-semibold">Наши товары</h1>

        {products.length === 0 ? (
          <p className="text-center text-gray-500">Товары не найдены</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4">
            {products.map(p => (
              <ProductCard key={p._id} product={p} />
            ))}
          </div>
        )}

        <div className="mt-8">
          <Pagination currentPage={currentPage} totalPages={totalPages} basePath="/" />
        </div>
      </main>
    </div>
  )
}
