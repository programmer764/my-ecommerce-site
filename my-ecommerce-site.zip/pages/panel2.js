const Panel2 = () => {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-4xl mb-4">Панель 2</h1>
        <p>Это содержимое второй панели.</p>
      </div>
    )
  }
  
  export default Panel2
  