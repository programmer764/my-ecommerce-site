const Panel1 = () => {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-4xl mb-4">Панель 1</h1>
        <p>Это содержимое первой панели.</p>
      </div>
    )
  }
  
  export default Panel1
  