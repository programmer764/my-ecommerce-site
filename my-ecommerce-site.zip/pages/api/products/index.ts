// pages/api/products/index.ts

import type { NextApiRequest, NextApiResponse } from 'next'
import clientPromise from '@/lib/mongo'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method Not Allowed' })
  }

  // 1) Забираем все параметры из query
  const {
    search,
    categorySlug,
    brand,
    country,
    compressor,
    remoteControl,
    minPrice, maxPrice,
    minArea,   maxArea,
    minHeat,   maxHeat,
    minCool,   maxCool,
    minNoise,  maxNoise,
    page = '1'
  } = req.query as Record<string, string>

  const skip  = (parseInt(page, 10) - 1) * 15
  const limit = 15

  const client = await clientPromise
  const coll   = client.db('dbcom').collection('dbcom2')

  // 2) Собираем “строковые” фильтры в массив
  const andConditions: any[] = []

  if (categorySlug && categorySlug !== 'Все') {
    andConditions.push({ categorySlug })
  }
  if (search) {
    andConditions.push({ name: { $regex: search.trim(), $options: 'i' } })
  }
  if (brand && brand !== 'Все') {
    andConditions.push({
      characteristics: {
        $elemMatch: { name: 'Производитель', value: brand }
      }
    })
  }
  if (country && country !== 'Все') {
    andConditions.push({
      characteristics: {
        $elemMatch: { name: 'Страна бренда', value: country }
      }
    })
  }
  if (compressor && compressor !== 'Все') {
    andConditions.push({
      characteristics: {
        $elemMatch: { name: 'Компрессор', value: compressor }
      }
    })
  }
  if (remoteControl === 'true') {
    andConditions.push({
      characteristics: {
        $elemMatch: {
          name:  'Пульт дистанционного управления',
          value: 'Есть'
        }
      }
    })
  }
  if (minPrice || maxPrice) {
    const q: any = {}
    if (minPrice) q.$gte = parseFloat(minPrice)
    if (maxPrice) q.$lte = parseFloat(maxPrice)
    andConditions.push({ price: q })
  }

  // 3) Начинаем агрегационный pipeline
  const pipeline: any[] = []

  // 3.1) Применяем все строковые фильтры
  if (andConditions.length > 0) {
    pipeline.push({ $match: { $and: andConditions } })
  }

  // Хелпер для “парсинга” первой цифры из строки в число
  const makeNumericField = (charName: string, asField: string) => ({
    $addFields: {
      [asField]: {
        $let: {
          vars: {
            rf: {
              $regexFind: {
                input: {
                  $first: {
                    $map: {
                      input: {
                        $filter: {
                          input: '$characteristics',
                          as:    'c',
                          cond:  { $eq: ['$$c.name', charName] }
                        }
                      },
                      as: 'x',
                      in: '$$x.value'
                    }
                  }
                },
                regex: '[0-9]+(?:[\\.,][0-9]+)?'
              }
            }
          },
          in: {
            $toDouble: {
              $replaceAll: {
                input:       '$$rf.match',
                find:        ',',
                replacement: '.'
              }
            }
          }
        }
      }
    }
  })

  // 3.2) Добавляем парсинг для всех нужных числовых фильтров
  pipeline.push(makeNumericField('Площадь помещения, кв.м.',       'areaNum'))
  pipeline.push(makeNumericField('Обогрев, кВт',                  'heatNum'))
  pipeline.push(makeNumericField('Охлаждение, кВт',               'coolNum'))
  pipeline.push(makeNumericField('Уровень шума внут. блока, дБ',  'noiseNum'))

  // 4) Собираем “числовые” фильтры 
  const numMatch: any = {}
  if (minArea  || maxArea)  numMatch.areaNum  = {
    ...(minArea ? { $gte: +minArea } : {}),
    ...(maxArea ? { $lte: +maxArea } : {})
  }
  if (minHeat  || maxHeat)  numMatch.heatNum  = {
    ...(minHeat ? { $gte: +minHeat } : {}),
    ...(maxHeat ? { $lte: +maxHeat } : {})
  }
  if (minCool  || maxCool)  numMatch.coolNum  = {
    ...(minCool ? { $gte: +minCool } : {}),
    ...(maxCool ? { $lte: +maxCool } : {})
  }
  if (minNoise || maxNoise) numMatch.noiseNum = {
    ...(minNoise ? { $gte: +minNoise } : {}),
    ...(maxNoise ? { $lte: +maxNoise } : {})
  }

  if (Object.keys(numMatch).length > 0) {
    pipeline.push({ $match: numMatch })
  }

  // 5) Фасет для пагинации + подсчёта общего числа
  pipeline.push({
    $facet: {
      data: [
        { $skip: skip },
        { $limit: limit }
      ],
      count: [
        { $count: 'total' }
      ]
    }
  })

  // 6) Выполняем агрегирование
  const [agg] = await coll.aggregate(pipeline).toArray()
  const products   = agg.data
  const totalCount = agg.count[0]?.total || 0

  return res.status(200).json({ products, totalCount })
}
