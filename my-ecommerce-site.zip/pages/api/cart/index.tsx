import type { NextApiRequest, NextApiResponse } from 'next'
import clientPromise from '@/lib/mongo'
import { withAuth } from '@/lib/withauth'

async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Забираем user из req, приведя тип
  const user = (req as any).user as { id: string; email: string }
  const { id: userId, email } = user

  const client = await clientPromise
  const db = client.db('dbcom')
  const carts = db.collection('carts')

  if (req.method === 'GET') {
    const doc = await carts.findOne({ userId })
    return res.status(200).json(doc?.items || [])
  }

  if (req.method === 'POST') {
    const { items } = req.body

    // Валидация items
    if (!Array.isArray(items)) {
      return res.status(400).json({ message: 'Некорректный формат items' })
    }
    for (const item of items) {
      if (
        typeof item.cartId !== 'string' ||
        typeof item.quantity !== 'number' ||
        item.quantity <= 0
      ) {
        return res.status(400).json({ message: 'Некорректные данные в items' })
      }
    }

    await carts.updateOne(
      { userId },
      { $set: { items, updatedAt: new Date() } },
      { upsert: true }
    )

    // Логи
    const ip =
      req.headers['x-forwarded-for']?.toString() ||
      req.socket.remoteAddress ||
      'unknown'
    const userAgent = req.headers['user-agent'] || 'unknown'
    await db.collection('cart_logs').insertOne({
      userId,
      email,
      ip,
      userAgent,
      items,
      updatedAt: new Date(),
    })

    return res.status(200).json({ message: 'Обновлено' })
  }

  res.setHeader('Allow', ['GET', 'POST'])
  return res.status(405).end(`Method ${req.method} Not Allowed`)
}

// Оборачиваем без изменения сигнатуры: работает со стандартным NextApiRequest
export default withAuth(handler)
