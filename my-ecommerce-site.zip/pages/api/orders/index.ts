// pages/api/orders/index.ts
import type { NextApiRequest, NextApiResponse } from 'next'
import clientPromise from '@/lib/mongo'
import { verifyToken } from '@/lib/auth'
import { sendConfirmationEmail } from '@/lib/mail'
import { ObjectId } from 'mongodb'
import crypto from 'crypto'

type Order = {
  _id?: ObjectId
  email: string
  userId?: string
  items: Array<{ cartId: string; quantity: number }>
  total: number
  confirmed: boolean
  status: 'новый' | 'оплачен' | 'отправлен' | 'доставлен'
  confirmationToken?: string
  createdAt: Date
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  let client
  try {
    client = await clientPromise
  } catch (err) {
    console.error('MongoDB connect error:', err)
    return res.status(500).json({ message: 'Ошибка базы данных' })
  }

  const db = client.db('dbcom')
  const orders = db.collection<Order>('orders')

  let user: { id: string; email: string; role?: string } | null = null
  const token = req.cookies.token
  if (token) {
    try {
      user = await verifyToken(token)
    } catch {
      user = null
    }
  }

  // POST — создание заказа
  if (req.method === 'POST') {
    // CSRF-защита по Origin
    const origin = req.headers.origin || ''
    const allowedOrigin = process.env.CSRF_ALLOWED_ORIGIN
    
    if (origin !== allowedOrigin) {
      return res.status(403).json({ message: 'Запрещено: неверный origin' })
    }

    const { items, total, email } = req.body

    // Валидация
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: 'Корзина не может быть пустой' })
    }

    if (typeof total !== 'number' || total < 0) {
      return res.status(400).json({ message: 'Сумма должна быть положительным числом' })
    }

    if (!user && (!email || typeof email !== 'string' || !email.includes('@'))) {
      return res.status(400).json({ message: 'Email обязателен и должен быть корректным' })
    }

    const base: Partial<Order> = {
      email: user?.email || email!,
      items,
      total,
      status: 'новый',
      createdAt: new Date(),
    }

    if (user) {
      await orders.insertOne({
        ...base,
        confirmed: true,
        userId: user.id,
      } as Order)
      return res.status(201).json({ message: 'Заказ создан и подтверждён' })
    }

    const confirmationToken = crypto.randomBytes(16).toString('hex')
    await orders.insertOne({
      ...base,
      confirmed: false,
      confirmationToken,
    } as Order)

    try {
      await sendConfirmationEmail(email!, confirmationToken)
    } catch (err) {
      console.error('Ошибка отправки письма:', err)
    }

    return res.status(200).json({ message: 'Подтвердите заказ по ссылке в письме' })
  }

  // PUT — изменение статуса заказа (только admin)
  if (req.method === 'PUT') {
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'Нет доступа' })
    }

    const { id, status } = req.body as { id: string; status: Order['status'] }

    if (!ObjectId.isValid(id) || !['новый', 'оплачен', 'отправлен', 'доставлен'].includes(status)) {
      return res.status(400).json({ message: 'Неверные данные' })
    }

    await orders.updateOne({ _id: new ObjectId(id) }, { $set: { status } })
    return res.status(200).json({ message: 'Статус изменён' })
  }

  // GET — получение заказов с фильтрацией и пагинацией
  if (req.method === 'GET') {
    if (!user) {
      return res.status(401).json({ message: 'Требуется авторизация' })
    }

    const {
      email: searchEmail,
      status: searchStatus,
      confirmed: confirmedStr,
      limit: limitStr,
      skip: skipStr,
    } = req.query as Record<string, string>

    const limit = Math.min(parseInt(limitStr) || 20, 100)
    const skip = parseInt(skipStr) || 0

    const filter: any = {}
    if (user.role === 'admin') {
      if (searchEmail) {
        filter.email = { $regex: searchEmail, $options: 'i' }
      }
      if (confirmedStr === 'true') filter.confirmed = true
      if (confirmedStr === 'false') filter.confirmed = false
    } else {
      filter.email = user.email
    }

    if (searchStatus && searchStatus !== 'все') {
      filter.status = searchStatus
    }

    const [docs, totalCount] = await Promise.all([
      orders.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).toArray(),
      orders.countDocuments(filter),
    ])

    return res.status(200).json({
      data: docs,
      pagination: { total: totalCount, limit, skip },
    })
  }

  res.setHeader('Allow', ['GET', 'POST', 'PUT'])
  return res.status(405).end(`Method ${req.method} Not Allowed`)
}
