import { MongoClient } from "mongodb";

const uri = process.env.MONGODB_URI;
const dbName = "dbcom";

export default async function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ message: "Метод не разрешен" });
  }

  try {
    const client = await MongoClient.connect(uri);
    const db = client.db(dbName);
    const collection = db.collection("dbcom2");

    // Извлекаем параметры из запроса
    const { 
      search, 
      characteristics, 
      minPrice, 
      maxPrice, 
      brand, 
      country, 
      remoteControl, 
      mode, 
      mode2,
      page = 1 
    } = req.query;

    const query = {};
    
    if (search) {
      query.name = { $regex: search, $options: "i" };
    }

    if (characteristics) {
      const characteristicsArray = Array.isArray(characteristics)
        ? characteristics
        : characteristics.split(",");
      query.characteristics = { $elemMatch: { name: { $in: characteristicsArray } } };
    }

    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = parseInt(minPrice, 10);
      if (maxPrice) query.price.$lte = parseInt(maxPrice, 10);
    }

    // Фильтрация по бренду: ищем элемент characteristics с name "Бренд" и значением brand
    if (brand && brand !== "Все") {
      query.$and = query.$and || [];
      query.$and.push({
        characteristics: { $elemMatch: { name: "Бренд", value: brand } }
      });
    }
    
    // Фильтрация по стране бренда: ищем элемент с name "Страна бренда" и значением country
    if (country && country !== "Все") {
      query.$and = query.$and || [];
      query.$and.push({
        characteristics: { $elemMatch: { name: "Страна бренда", value: country } }
      });
    }

    // Фильтрация по наличию пульта дистанционного управления:
    // Если remoteControl равно "true" (и не "Все"), ищем характеристику "Пульт дистанционного управления" со значением "Есть"
    if (remoteControl !== "Все" && remoteControl === "true") {
      query.$and = query.$and || [];
      query.$and.push({
        characteristics: { $elemMatch: { name: "Пульт дистанционного управления", value: "Есть" } }
      });
    }

    // Фильтрация по режиму работы:
    if (mode) {
      query.$and = query.$and || [];
      query.$and.push({
        characteristics: { $elemMatch: { name: "Режим работы", value: mode } }
      });
    }
    // Фильтрация по типу компрессора 

   
    if (mode2 && mode2 !== "Все") {
      query.$and = query.$and || [];
      query.$and.push({
        characteristics: { $elemMatch: { name: "Компрессор", value: mode2 } }
      });      
      
    }
    console.log("MongoDB Query:", query);
    const limit = 15;
    const products = await collection
      .find(query)
      .skip((page - 1) * limit)
      .limit(limit)
      .toArray();
    const totalCount = await collection.countDocuments(query);

    client.close();
    res.status(200).json({ products, totalCount });
  } catch (error) {
    res.status(500).json({ message: "Ошибка сервера", error: error.message });
  }
}
