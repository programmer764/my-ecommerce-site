const Panel6 = () => {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-4xl mb-4">Панель 6</h1>
        <p>Это содержимое шестой панели.</p>
      </div>
    )
  }
  
  export default Panel6
  