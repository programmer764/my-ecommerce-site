
import DesktopHeader from '@/components/DesktopHeader'

export default function ProfilePage() {
  return (
    <>
     
      <div className="p-8 text-lg">👤 Это страница профиля пользователя</div>
    </>
  )
}
