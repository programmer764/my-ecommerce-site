// pages/index.js
import { useState, useEffect } from 'react'
import axios from 'axios'
import clientPromise from '@/lib/mongo'
import ProductCard from '@/components/ProductCard'
import ProductFilter from '@/components/ProductFilter'
import Pagination from '@/components/Pagination'
import FilterButton from '@/components/FilterButton'
import BannerSlider from '@/components/BannerSlider'
import EquipmentPickerForm from '@/components/EquipmentPickerForm'
import InfoBanner from '@/components/InfoBanner'
import BrandGallery from '@/components/BrandGallery'
import ServiceBlocks from '@/components/ServiceBlocks'

export async function getServerSideProps({ query }) {
  // 1) Получаем товары + общее число
  const { data } = await axios.get(
    `${process.env.NEXT_PUBLIC_BASE_URL}/api/products`,
    { params: query }
  )
  const { products, totalCount } = data
 fetch('/api/csrf', { credentials: 'include' })
  // 2) Собираем бренды и страны из ВСЕХ товаров
  const client = await clientPromise
  const coll = client.db('dbcom').collection('dbcom2')

  const docsB = await coll
    .find({ 'characteristics.name': 'Производитель' })
    .project({ characteristics: 1 })
    .toArray()
  const availableBrands = Array.from(new Set(
    docsB
      .map(d => d.characteristics.find(c => c.name === 'Производитель')?.value)
      .filter(Boolean)
  ))

  const docsC = await coll
    .find({ 'characteristics.name': 'Страна бренда' })
    .project({ characteristics: 1 })
    .toArray()
  const availableCountries = Array.from(new Set(
    docsC
      .map(d => d.characteristics.find(c => c.name === 'Страна бренда')?.value)
      .filter(Boolean)
  ))

  return {
    props: {
      products,
      totalCount,
      currentPage: parseInt(query.page || '1', 10),
      availableBrands,
      availableCountries
    }
  }
}

export default function Home({
  products,
  totalCount,
  currentPage,
  availableBrands,
  availableCountries
}) {
  const [showFilter, setShowFilter] = useState(false)
  const [isClient, setIsClient] = useState(false)
  useEffect(() => setIsClient(true), [])

  const totalPages = Math.ceil(totalCount / 15)

  return (

    
    <div className="mt-4  flex flex-col lg:flex-row gap-4 ">

      {/* мобильная кнопка */}
      <div className="mb-2 lg:hidden">
        <FilterButton
          showFilter={showFilter}
          toggleFilter={() => setShowFilter(!showFilter)}
        />
      </div>

      {/* фильтр */}
      


      {/* товары */}
      
      <main className="flex-1 min-w-0">
      
        <nav className="  text-sm ">
          
        <ul className="flex flex-wrap justify-center items-center gap-4  bg-white text-lg font-medium mb-3">
  {[
    { href: "#about", label: "О компании" },
    { href: "#payment", label: "Оплата и доставка" },
    { href: "#guarantee", label: "Гарантия" },
    { href: "#projects", label: "Наши работы" },
    { href: "#installation", label: "Монтаж и согласование" },
    { href: "#contact", label: "Контакты" },
  ].map((item, idx) => (
    <li key={idx}>
      <a
        href={item.href}
        className="px-4 py-2 text-black hover:text-blue-900 transition-colors duration-200"
      >
        {item.label}
      </a>
    </li>
  ))}
</ul>

<hr className="border-t-4 border-black w-full" />

      </nav>      
        <>
          <div className="flex mb-[50px] justify-center gap-6 max-w-7xl mx-auto px-4 h-[600px]">
            {/* Левая колонка */}
            <div className="flex-[2] flex flex-col gap-4 min-w-0">
              <div className="flex-[2] bg-white rounded shadow overflow-hidden">
                <BannerSlider />
              </div>
              <div className="flex-[1] bg-white rounded shadow overflow-hidden">
                <InfoBanner />
              </div>
            </div>
            {/* Правая колонка */}
            <div className="flex-[1] min-w-0">
              <div className="h-full w-full bg-white rounded shadow overflow-hidden">
                <EquipmentPickerForm />
              </div>
            </div>
          </div>
          <ServiceBlocks/>
          <BrandGallery/>
          
        </>

        
      </main>
    </div>
  )
}
