const Panel3 = () => {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-4xl mb-4">Панель 3</h1>
        <p>Это содержимое третьей панели.</p>
      </div>
    )
  }
  
  export default Panel3
  