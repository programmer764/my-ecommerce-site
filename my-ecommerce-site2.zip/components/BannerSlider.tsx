'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'

const banners = [
  {
    id: 1,
    src: '/banners/banner1.jpg',
    alt: 'Баннер 1',
  },
  {
    id: 2,
    src: '/banners/banner2.jpg',
    alt: 'Баннер 2',
  },
  {
    id: 3,
    src: '/banners/banner3.jpg',
    alt: 'Баннер 3',
  },
  {
    id: 4,
    src: '/banners/banner4.jpg',
    alt: 'Баннер 4',
  },
  {
    id: 5,
    src: '/banners/banner5.jpg',
    alt: 'Баннер 5',
  },{
    id: 6,
    src: '/banners/banner6.jpg',
    alt: 'Баннер 6',
  },{
    id: 7,
    src: '/banners/banner7.jpg',
    alt: 'Баннер 7',
  },{
    id: 8,
    src: '/banners/banner8.jpg',
    alt: 'Баннер 8',
  },{
    id: 9,
    src: '/banners/banner9.jpg',
    alt: 'Баннер 9',
  },{
    id: 10,
    src: '/banners/banner10.jpg',
    alt: 'Баннер 10',
  },
  {
    id: 11,
    src: '/banners/banner11.jpg',
    alt: 'Баннер 11',
  },
]

export default function BannerSlider() {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % banners.length)
    }, 5000) // каждые 5 секунд
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative w-full h-[400px] overflow-hidden rounded-xl shadow-lg">
      <AnimatePresence mode="wait">
        <motion.div
          key={banners[index].id}
          initial={{ x: '-100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ duration: 0.1 }}
          className="absolute w-full h-full"
        >
          <Image
            src={banners[index].src}
            alt={banners[index].alt}
            fill
            className="object-cover"
          />
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
